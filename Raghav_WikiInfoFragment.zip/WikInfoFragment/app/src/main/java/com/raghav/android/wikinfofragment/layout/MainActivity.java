package com.raghav.android.wikinfofragment.layout;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.raghav.android.wikinfofragment.R;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    String selectedGrp;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,
                new String[]
                        {
                                "Games",
                                "Cars",
                                "Fruits"
                        });

        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), SubListActivity.class);
                switch (i) {
                    case 0:
                        intent.putExtra("group", 0);
                        break;
                    case 1:
                        intent.putExtra("group", 1);
                        break;
                    case 2:
                        intent.putExtra("group", 2);
                        break;
                }
                startActivity(intent);
            }
        });
    }
}