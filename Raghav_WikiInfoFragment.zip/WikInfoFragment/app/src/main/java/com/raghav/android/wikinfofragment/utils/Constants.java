package com.raghav.android.wikinfofragment.utils;


public class Constants {

    private static String[] _Games =
            {
                    "Dota",
                    "Counter_Strike",
                    "League_of_legends",
                    "VainGlory",
                    "Mario"
            };
    private static String[] _Cars =
            {
                    "Ferrari",
                    "Lamborghini",
                    "Lexus",
                    "Ford",
                    "Honda"
            };
    private static String[] _Fruits =
            {
                    "Apple",
                    "Banana",
                    "Mango",
                    "Orange",
                    "Strawberry"
            };

    public static String[] get_games() {
        return _Games;
    }

    public static String[] get_cars() {
        return _Cars;
    }

    public static String[] get_fruits() {
        return _Fruits;
    }
}
