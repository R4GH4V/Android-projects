package com.example.android.webviewlist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class Main2Activity extends AppCompatActivity {

    WebView w;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        w=(WebView) findViewById(R.id.web);

        Intent in=getIntent();
        Bundle b=in.getExtras();
        String data=b.getString("a");
        w.loadUrl("https://en.wikipedia.org/wiki/"+data);
    }
}
